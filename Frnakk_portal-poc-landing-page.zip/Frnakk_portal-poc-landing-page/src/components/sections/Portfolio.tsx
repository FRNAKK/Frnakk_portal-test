'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';

const Portfolio = () => {
  const [activeFilter, setActiveFilter] = useState('all');

  const filters = [
    { id: 'all', label: 'All Work' },
    { id: 'video', label: 'Video Editing' },
    { id: 'motion', label: 'Motion Graphics' },
    { id: 'design', label: 'Design' },
  ];

  const projects = [
    {
      id: 1,
      title: 'Brand Identity Motion',
      category: 'motion',
      image: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800&q=80',
      description: 'Animated brand identity for tech startup',
      color: 'bg-accent-purple',
    },
    {
      id: 2,
      title: 'Corporate Video',
      category: 'video',
      image: 'https://images.unsplash.com/photo-1492619375914-88005aa9e8fb?w=800&q=80',
      description: 'Commercial video production',
      color: 'bg-accent-blue',
    },
    {
      id: 3,
      title: 'Product Showcase',
      category: 'video',
      image: 'https://images.unsplash.com/photo-1536240478700-b869070f9279?w=800&q=80',
      description: 'Dynamic product presentation',
      color: 'bg-primary',
    },
    {
      id: 4,
      title: 'UI/UX Design',
      category: 'design',
      image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&q=80',
      description: 'Modern interface design',
      color: 'bg-accent-green',
    },
    {
      id: 5,
      title: 'Title Sequences',
      category: 'motion',
      image: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=800&q=80',
      description: 'Cinematic opening titles',
      color: 'bg-accent-purple',
    },
    {
      id: 6,
      title: 'Social Media Content',
      category: 'video',
      image: 'https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?w=800&q=80',
      description: 'Engaging social media videos',
      color: 'bg-primary',
    },
  ];

  const filteredProjects =
    activeFilter === 'all'
      ? projects
      : projects.filter((p) => p.category === activeFilter);

  return (
    <section id="work" className="section-padding bg-white">
      <div className="container-custom">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="text-primary font-semibold tracking-wide uppercase text-sm mb-4">
            Portfolio
          </p>
          <h2 className="text-5xl md:text-6xl font-bold text-neutral-900 mb-6">
            Selected Work
          </h2>
          <p className="text-xl text-neutral-600 max-w-2xl mx-auto">
            A collection of projects that showcase my passion for visual storytelling and creative excellence.
          </p>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex flex-wrap justify-center gap-4 mb-12"
        >
          {filters.map((filter) => (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.id)}
              className={`px-6 py-3 rounded-lg font-medium transition-all ${
                activeFilter === filter.id
                  ? 'bg-primary text-white shadow-lg shadow-primary/30'
                  : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </motion.div>

        {/* Projects Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {filteredProjects.map((project, index) => (
            <motion.div
              key={project.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="group cursor-pointer"
            >
              <div className="relative overflow-hidden rounded-2xl aspect-[4/3] bg-neutral-100">
                {/* Image */}
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />

                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 via-neutral-900/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                  <motion.div
                    initial={{ y: 20, opacity: 0 }}
                    whileInView={{ y: 0, opacity: 1 }}
                    transition={{ duration: 0.3 }}
                  >
                    <h3 className="text-white text-2xl font-bold mb-2">
                      {project.title}
                    </h3>
                    <p className="text-neutral-300 text-sm">
                      {project.description}
                    </p>
                  </motion.div>
                </div>

                {/* Category Badge */}
                <div className="absolute top-4 right-4">
                  <span
                    className={`${project.color} text-white text-xs font-semibold px-3 py-1 rounded-full`}
                  >
                    {filters.find((f) => f.id === project.category)?.label}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* View More Button */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center mt-16"
        >
          <motion.a
            href="#"
            className="inline-block px-8 py-4 bg-neutral-900 text-white rounded-lg font-semibold hover:bg-neutral-800 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            View All Projects
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
};

export default Portfolio;
