'use client';

import { motion } from 'framer-motion';

const About = () => {
  const services = [
    {
      icon: '🎬',
      title: 'Video Editing',
      description: 'Professional video editing with a keen eye for storytelling and pacing.',
    },
    {
      icon: '✨',
      title: 'Motion Graphics',
      description: 'Dynamic animations and motion design that bring ideas to life.',
    },
    {
      icon: '🎨',
      title: 'Creative Design',
      description: 'Visual design solutions that captivate and communicate effectively.',
    },
    {
      icon: '🎭',
      title: 'Brand Identity',
      description: 'Cohesive brand experiences across all visual touchpoints.',
    },
  ];

  const stats = [
    { number: '150+', label: 'Projects Completed' },
    { number: '50+', label: 'Happy Clients' },
    { number: '5+', label: 'Years Experience' },
    { number: '20+', label: 'Awards Won' },
  ];

  return (
    <>
      {/* About Section */}
      <section id="about" className="section-padding bg-neutral-50">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Left: Image */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden aspect-square">
                <img
                  src="https://images.unsplash.com/photo-1542038784456-1ea8e935640e?w=800&q=80"
                  alt="About"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent" />
              </div>

              {/* Decorative Element */}
              <motion.div
                className="absolute -bottom-6 -right-6 w-64 h-64 bg-primary/10 rounded-full blur-3xl -z-10"
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.3, 0.5, 0.3],
                }}
                transition={{
                  duration: 6,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
            </motion.div>

            {/* Right: Content */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <p className="text-primary font-semibold tracking-wide uppercase text-sm mb-4">
                About Me
              </p>
              <h2 className="text-5xl md:text-6xl font-bold text-neutral-900 mb-6">
                Crafting Visual Stories
              </h2>
              <div className="space-y-4 text-lg text-neutral-600 leading-relaxed">
                <p>
                  I'm a creative professional specializing in video editing, motion graphics, and visual design. With over 5 years of experience, I've helped brands and businesses tell their stories through compelling visual content.
                </p>
                <p>
                  My approach combines technical expertise with artistic vision, ensuring every project not only looks stunning but also achieves its intended impact.
                </p>
                <p>
                  Whether it's a commercial, social media content, or a full brand identity, I bring passion and precision to every frame.
                </p>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-8 mt-12">
                {stats.map((stat, index) => (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                  >
                    <h3 className="text-4xl font-bold text-primary mb-2">
                      {stat.number}
                    </h3>
                    <p className="text-neutral-600">{stat.label}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="section-padding bg-white">
        <div className="container-custom">
          {/* Section Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <p className="text-primary font-semibold tracking-wide uppercase text-sm mb-4">
              Services
            </p>
            <h2 className="text-5xl md:text-6xl font-bold text-neutral-900 mb-6">
              What I Do
            </h2>
            <p className="text-xl text-neutral-600 max-w-2xl mx-auto">
              Comprehensive creative services to bring your vision to life.
            </p>
          </motion.div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -10 }}
                className="bg-neutral-50 p-8 rounded-2xl hover:shadow-xl transition-all duration-300 group"
              >
                <div className="text-5xl mb-6 group-hover:scale-110 transition-transform duration-300">
                  {service.icon}
                </div>
                <h3 className="text-2xl font-bold text-neutral-900 mb-4">
                  {service.title}
                </h3>
                <p className="text-neutral-600 leading-relaxed">
                  {service.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default About;
